package com.example.loyalty;

import com.example.loyalty.service.*;
import io.vertx.core.*;
import io.vertx.core.http.HttpServerOptions;
import io.vertx.ext.web.Router;

public class LoyaltyServiceVerticle extends AbstractVerticle {

    @Override
    public void start(Promise<Void> startPromise) {

        FxClient fxClient = new FxClient(vertx, config());
        PromoClient promoClient = new PromoClient(vertx, config());
        LoyaltyPointCalculator calculator = new LoyaltyPointCalculator();

        LoyaltyPointsHandler handler =
                new LoyaltyPointsHandler(fxClient, promoClient, calculator);

        Router router = Router.router(vertx);
        router.post("/v1/points/quote")
                .handler(io.vertx.ext.web.handler.BodyHandler.create())
                .handler(handler::handleQuote);

        vertx.createHttpServer(new HttpServerOptions().setPort(0))
                .requestHandler(router)
                .listen()
                .onSuccess(server -> {
                    System.out.println("Running on port: " + server.actualPort());
                    startPromise.complete();
                })
                .onFailure(startPromise::fail);
    }
}
