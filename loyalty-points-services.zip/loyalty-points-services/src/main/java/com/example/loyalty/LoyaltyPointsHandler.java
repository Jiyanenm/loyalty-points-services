package com.example.loyalty;

import com.example.loyalty.model.*;
import com.example.loyalty.service.*;
import io.vertx.core.CompositeFuture;
import io.vertx.ext.web.RoutingContext;

import java.math.BigDecimal;

public class LoyaltyPointsHandler {

    private final FxClient fxClient;
    private final PromoClient promoClient;
    private final LoyaltyPointCalculator calculator;

    public LoyaltyPointsHandler(FxClient fx, PromoClient promo, LoyaltyPointCalculator calc) {
        this.fxClient = fx;
        this.promoClient = promo;
        this.calculator = calc;
    }

    public void handleQuote(RoutingContext ctx) {
        PointsQuoteRequest req;
        try {
            req = ctx.body().asPojo(PointsQuoteRequest.class);
        } catch (Exception e) {
            ctx.response().setStatusCode(400).end("Invalid JSON");
            return;
        }

        var validation = Validator.validate(req);
        if (validation.isPresent()) {
            ctx.response().setStatusCode(400).end(validation.get());
            return;
        }

        CompositeFuture
                .all(
                        fxClient.getRate(req.currency()),
                        promoClient.fetchPromo(req.promoCode())
                )
                .onSuccess(cf -> {
                    var fx = cf.resultAt(0);
                    var promo = cf.resultAt(1);

                    var resp = calculator.calculate(req, (BigDecimal) fx, (PromoClient.PromoRule) promo);
                    ctx.response()
                            .putHeader("Content-Type", "application/json")
                            .end(io.vertx.core.json.Json.encode(resp));
                })
                .onFailure(err ->
                        ctx.response()
                                .setStatusCode(502)
                                .end("External service failure"));
    }
}
