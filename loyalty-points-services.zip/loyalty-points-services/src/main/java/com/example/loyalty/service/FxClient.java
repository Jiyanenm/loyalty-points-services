package com.example.loyalty.service;

import io.vertx.core.*;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.client.WebClient;

import java.math.BigDecimal;

public class FxClient {

    private final WebClient client;
    private final String baseUrl;

    public FxClient(Vertx vertx, JsonObject config) {
        this.client = WebClient.create(vertx);
        this.baseUrl = config.getString("fxUrl");
    }

    public Future<BigDecimal> getRate(String currency) {
        Promise<BigDecimal> promise = Promise.promise();
        attempt(currency, 1, promise);
        return promise.future();
    }

    private void attempt(String currency, int attempt, Promise<BigDecimal> promise) {

        client.getAbs(baseUrl + "/fx/" + currency)
                .send()
                .onSuccess(resp -> {
                    if (resp.statusCode() != 200) {
                        failOrRetry(currency, attempt, promise);
                        return;
                    }
                    // Corrected: get value and convert to BigDecimal
                    Object rateObj = resp.bodyAsJsonObject().getValue("rate");
                    BigDecimal rate;
                    try {
                        rate = new BigDecimal(rateObj.toString());
                        promise.complete(rate);
                    } catch (NumberFormatException e) {
                        promise.fail("Invalid FX rate format: " + rateObj);
                    }
                })
                .onFailure(err -> failOrRetry(currency, attempt, promise));
    }


    private void failOrRetry(String currency, int attempt, Promise<BigDecimal> promise) {
        if (attempt >= 3) {
            promise.fail("FX service failed after retries");
        } else {
            long delay = (long) Math.pow(2, attempt) * 100L; // 100ms, 200ms, 400ms
            Vertx.currentContext().owner().setTimer(delay,
                    t -> attempt(currency, attempt + 1, promise));
        }
    }
}
