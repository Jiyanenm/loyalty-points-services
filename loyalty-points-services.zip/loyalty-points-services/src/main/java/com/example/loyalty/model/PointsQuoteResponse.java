package com.example.loyalty.model;

import java.math.BigDecimal;
import java.util.List;

public record PointsQuoteResponse(
        int basePoints,
        int tierBonus,
        int promoBonus,
        int totalPoints,
        BigDecimal effectiveFxRate,
        List<String> warnings
) {}
