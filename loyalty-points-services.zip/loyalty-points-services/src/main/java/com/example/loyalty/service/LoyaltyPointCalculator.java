package com.example.loyalty.service;

import com.example.loyalty.model.*;

import java.math.BigDecimal;
import java.util.*;

public class LoyaltyPointCalculator {

    public PointsQuoteResponse calculate(PointsQuoteRequest req,
                                         BigDecimal fxRate,
                                         PromoClient.PromoRule promo) {

        BigDecimal converted = req.fareAmount().multiply(fxRate);
        int basePoints = converted.setScale(0, BigDecimal.ROUND_DOWN).intValue();

        int tierBonus = tierBonus(req.customerTier(), basePoints);

        int promoBonus = (int) Math.floor(basePoints * promo.bonusMultiplier());

        int total = basePoints + tierBonus + promoBonus;
        if (total > 50000) total = 50000;

        List<String> warnings = new ArrayList<>();
        if (promo.expiresInDays() <= 3) warnings.add("PROMO_EXPIRES_SOON");

        return new PointsQuoteResponse(
                basePoints,
                tierBonus,
                promoBonus,
                total,
                fxRate,
                warnings
        );
    }

    private int tierBonus(CustomerTier tier, int base) {
        return switch (tier) {
            case NONE -> 0;
            case SILVER -> (int) Math.floor(base * 0.15);
            case GOLD -> (int) Math.floor(base * 0.30);
            case PLATINUM -> (int) Math.floor(base * 0.50);
        };
    }
}
