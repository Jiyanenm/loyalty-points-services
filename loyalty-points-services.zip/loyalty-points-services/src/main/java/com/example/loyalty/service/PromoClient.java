package com.example.loyalty.service;

import io.vertx.core.*;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.client.WebClient;
//PromoClient.java (timeout + fallback)
public class PromoClient {

    private final WebClient client;
    private final String baseUrl;
    private final long timeoutMs = 300;

    public record PromoRule(double bonusMultiplier, int expiresInDays) {}

    public PromoClient(Vertx vertx, JsonObject config) {
        this.client = WebClient.create(vertx);
        this.baseUrl = config.getString("promoUrl");
    }

    public Future<PromoRule> fetchPromo(String code) {
        Promise<PromoRule> promise = Promise.promise();

        client.getAbs(baseUrl + "/promo/" + code)
                .timeout(timeoutMs)
                .send()
                .onSuccess(resp -> {
                    if (resp.statusCode() != 200) {
                        promise.complete(new PromoRule(0, 999));
                        return;
                    }
                    var json = resp.bodyAsJsonObject();
                    promise.complete(new PromoRule(
                            json.getDouble("bonusMultiplier"),
                            json.getInteger("expiresInDays")
                    ));
                })
                .onFailure(err ->
                        // fallback
                        promise.complete(new PromoRule(0, 999))
                );

        return promise.future();
    }
}
