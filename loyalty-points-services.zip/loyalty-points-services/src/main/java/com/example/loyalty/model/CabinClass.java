package com.example.loyalty.model;

public enum CabinClass {
    ECONOMY, PREMIUM_ECONOMY, BUSINESS, FIRST
}
