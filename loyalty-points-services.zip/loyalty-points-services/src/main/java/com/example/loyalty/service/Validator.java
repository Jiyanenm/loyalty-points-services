package com.example.loyalty.service;

import com.example.loyalty.model.*;

import java.util.Optional;

public class Validator {

    public static Optional<String> validate(PointsQuoteRequest req) {

        if (req.fareAmount() == null || req.fareAmount().doubleValue() <= 0)
            return Optional.of("Invalid fareAmount");

        if (req.currency() == null || req.currency().isBlank())
            return Optional.of("Invalid currency");

        if (req.cabinClass() == null)
            return Optional.of("Invalid cabinClass");

        if (req.customerTier() == null)
            return Optional.of("Invalid customerTier");

        return Optional.empty();
    }
}
