package com.example.loyalty.util;

public class JsonUtil {
}
