package com.example.loyalty.model;

public enum CustomerTier {
    NONE, SILVER, GOLD, PLATINUM
}
