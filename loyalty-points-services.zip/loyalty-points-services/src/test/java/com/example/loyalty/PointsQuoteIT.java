package com.example.loyalty;

import com.github.tomakehurst.wiremock.WireMockServer;
import io.vertx.core.DeploymentOptions;
import io.vertx.core.Vertx;
import io.vertx.ext.web.client.WebClient;
import io.vertx.junit5.*;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.stubbing.Scenario.STARTED;

@ExtendWith(VertxExtension.class)
public class PointsQuoteIT {

    static WireMockServer fx = new WireMockServer(0);
    static WireMockServer promo = new WireMockServer(0);
    int port;

    @BeforeAll
    static void startServers() {
        fx.start();
        promo.start();
    }

    @AfterAll
    static void stopServers() {
        fx.stop();
        promo.stop();
    }

    @BeforeEach
    void deploy(Vertx vertx, VertxTestContext tc) {

        var config = new io.vertx.core.json.JsonObject()
                .put("fxUrl", "http://localhost:" + fx.port())
                .put("promoUrl", "http://localhost:" + promo.port());

        vertx.deployVerticle(new LoyaltyServiceVerticle(),
                        new DeploymentOptions().setConfig(config))
                .onSuccess(id -> tc.completeNow())
                .onFailure(tc::failNow);
    }

    // Utility: send request
    private io.vertx.core.Future<io.vertx.ext.web.client.HttpResponse<io.vertx.core.buffer.Buffer>>
    send(Vertx vertx, String json) {
        return WebClient.create(vertx)
                .post(0, "localhost", "/v1/points/quote")
                .sendBuffer(io.vertx.core.buffer.Buffer.buffer(json));
    }

    @Test
    void successFullFlow(Vertx vertx, VertxTestContext tc) {

        fx.stubFor(get(urlEqualTo("/fx/USD"))
                .willReturn(okJson("{\"rate\":3.67}")));

        promo.stubFor(get(urlEqualTo("/promo/SUMMER25"))
                .willReturn(okJson("""
                    {"bonusMultiplier":0.25,"expiresInDays":2}
                """)));

        send(vertx, """
            {"fareAmount":1234.50,"currency":"USD",
             "cabinClass":"ECONOMY","customerTier":"SILVER",
             "promoCode":"SUMMER25"}""")
                .onSuccess(resp -> {
                    Assertions.assertThat(resp.statusCode()).isEqualTo(200);
                    var body = resp.bodyAsJsonObject();
                    Assertions.assertThat(body.getInteger("basePoints")).isEqualTo(1234);
                    Assertions.assertThat(body.getJsonArray("warnings"))
                            .contains("PROMO_EXPIRES_SOON");
                    tc.completeNow();
                })
                .onFailure(tc::failNow);
    }

    @Test
    void promoTimeoutFallback(Vertx vertx, VertxTestContext tc) {

        fx.stubFor(get("/fx/USD").willReturn(okJson("{\"rate\":3.0}")));
        promo.stubFor(get("/promo/SUMMER25")
                .willReturn(aResponse().withFixedDelay(2000)));

        send(vertx, """
            {"fareAmount":100,"currency":"USD",
             "cabinClass":"ECONOMY","customerTier":"NONE",
             "promoCode":"SUMMER25"}""")
                .onSuccess(resp -> {
                    var json = resp.bodyAsJsonObject();
                    Assertions.assertThat(json.getInteger("promoBonus")).isZero();
                    tc.completeNow();
                })
                .onFailure(tc::failNow);
    }

    @Test
    void fxRetrySuccess(Vertx vertx, VertxTestContext tc) {

        fx.stubFor(get("/fx/USD")
                .inScenario("retry")
                .whenScenarioStateIs(STARTED)
                .willSetStateTo("second")
                .willReturn(serverError()));

        fx.stubFor(get("/fx/USD")
                .inScenario("retry")
                .whenScenarioStateIs("second")
                .willReturn(okJson("{\"rate\":5}")));

        promo.stubFor(get(anyUrl()).willReturn(okJson("{\"bonusMultiplier\":0,\"expiresInDays\":10}")));

        send(vertx, """
            {"fareAmount":100,"currency":"USD",
             "cabinClass":"ECONOMY","customerTier":"NONE",
             "promoCode":""}""")
                .onSuccess(resp -> {
                    Assertions.assertThat(resp.statusCode()).isEqualTo(200);
                    tc.completeNow();
                })
                .onFailure(tc::failNow);
    }

    @Test
    void pointCap(Vertx vertx, VertxTestContext tc) {

        fx.stubFor(get("/fx/USD").willReturn(okJson("{\"rate\":100}")));
        promo.stubFor(get(anyUrl()).willReturn(okJson("{\"bonusMultiplier\":0.5,\"expiresInDays\":10}")));

        send(vertx, """
            {"fareAmount":500,"currency":"USD",
             "cabinClass":"ECONOMY","customerTier":"PLATINUM",
             "promoCode":""}""")
                .onSuccess(resp -> {
                    Assertions.assertThat(resp.bodyAsJsonObject().getInteger("totalPoints"))
                            .isEqualTo(50000);
                    tc.completeNow();
                })
                .onFailure(tc::failNow);
    }
}
